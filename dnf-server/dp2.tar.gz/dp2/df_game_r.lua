local dp = _DP
local dpx = _DPX
local log = dp.log

log.info("hello world!")
-- talk is cheap, show me the code !
